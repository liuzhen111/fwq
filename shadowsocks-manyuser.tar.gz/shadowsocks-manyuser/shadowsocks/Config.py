#Config
MYSQL_HOST = '61.195.108.89'
MYSQL_PORT = 3306
MYSQL_USER = 'fq'
MYSQL_PASS = '0966'
MYSQL_DB = 'radius'

MANAGE_PASS = 'ss233333333'
#if you want manage in other server you should set this value to global ip
MANAGE_BIND_IP = '127.0.0.1'
#make sure this port is idle
MANAGE_PORT = 23333
